function [ c ] = perceptronClassify( XTest, w)

%filler code - replace with your code
c = ones(size(XTest,1),1);

end

