function [ w ] = kernelWeights( XTrain, yTrain, nIter, d )

% filler code - replace with your code
nTrain = size(XTrain,1);
w = zeros(nTrain,1);


end

