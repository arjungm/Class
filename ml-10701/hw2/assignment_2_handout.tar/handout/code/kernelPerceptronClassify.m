function [ c ] = kernelPerceptronClassify( XTrain, XTest, w, d )

% filler code - replace with your code
nTest = size(XTest,1);
nTrain = size(XTrain,1);
c = ones(nTest,1);

end

