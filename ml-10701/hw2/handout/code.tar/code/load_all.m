load('../data/XTrainChallenge.mat')
load('../data/yTrainChallenge.mat')