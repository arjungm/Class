function [ p ] = pca( X, n)


%filler code - replace with your code
nFeat = size(X,2);
p = zeros(nFeat,n);

end

